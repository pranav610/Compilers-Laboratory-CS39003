#ifndef MYLH
#define MYLH
#define ERR 0
#define OK 1
int printStr(char *);
int printInt(int);
int readInt(int *);
int readFlt(float *);
int printFlt(float);
#endif